function [ X ] = D2plot( A ,X)

%plot(X(:,1),X(:,2),'*');
for i=2:length(A)
    for j=1:i-1
        if A(i,j)>0
            line([X(i,1),X(j,1)],[X(i,2),X(j,2)]); %plotting the lines between the coordinates
            %text((X(i,1)+X(j,1))/2,(X(i,2)+X(j,2))/2,num2str(A(i,j)));
        end
    end
end

end

